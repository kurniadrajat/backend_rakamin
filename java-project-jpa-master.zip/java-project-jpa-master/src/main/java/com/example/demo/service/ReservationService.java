package com.example.demo.service;

import com.example.demo.model.Reservation;
import com.example.demo.repository.ReservationRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class ReservationService {
    private final ReservationRepository reservationRepository;

    @Autowired
    public ReservationService(ReservationRepository reservationRepository) {
        this.reservationRepository = reservationRepository;
    }

    public Reservation createReservation(Reservation reservation) {
        return reservationRepository.save(reservation);
    }

    public List<Reservation> getAllReservations() {
        return reservationRepository.findAll();
    }

//    public List<Reservation> findByCustomerName(String customerName) {
//        // Contoh sederhana menggunakan stream untuk filter
//        // Dalam implementasi sebenarnya, Anda mungkin ingin menggunakan query database
//        return reservations.stream()
//                .filter(reservation -> reservation.getCustomerName().equalsIgnoreCase(customerName))
//                .collect(Collectors.toList());
//    }

    public Optional<Reservation> getReservationById(Long id) {
        return reservationRepository.findById(id);
    }

    // Metode tambahan jika diperlukan
}
