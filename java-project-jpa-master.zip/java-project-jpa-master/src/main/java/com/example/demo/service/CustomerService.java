package com.example.demo.service;

import com.example.demo.model.Customer;
import org.springframework.stereotype.Service;

import java.util.HashMap;
import java.util.Map;

@Service
public class CustomerService {
    private final Map<Long, Customer> customerData = new HashMap<>();

    public CustomerService() {
        // Pre-populate with some dummy data
        customerData.put(1L, new Customer(1L, "John Doe", 1000.00));
        customerData.put(2L, new Customer(2L, "Jane Doe", 1500.00));
    }

    public Customer getCustomerBalance(Long customerId) {
        return customerData.get(customerId);
    }
}
