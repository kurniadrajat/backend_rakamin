package com.example.jwttokenspring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtTokenSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
