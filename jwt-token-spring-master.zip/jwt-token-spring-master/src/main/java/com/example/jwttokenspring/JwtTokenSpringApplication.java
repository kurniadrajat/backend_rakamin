package com.example.jwttokenspring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtTokenSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtTokenSpringApplication.class, args);
	}

}
